# Roblox Gamepass UI Loader (Sans Pastebin)

Ce projet permet d'intégrer directement une interface d’achat de Gamepasses dans Roblox sans utiliser Pastebin ni loadstring.

## 📦 Utilisation

1. Copie le contenu de `src/GamepassUI.lua` dans un `LocalScript` (StarterGui ou StarterPlayerScripts)
2. Lance ton jeu dans Roblox Studio en mode `Play` (F5)
3. Clique sur les boutons pour acheter les Gamepasses

## ✅ Gamepasses supportés

- 🦝 Buy Racoon — ID `1258234209`
- 🌸 Buy Candy Blossom — ID `1256310976`
- 🦊 Buy Red Fox — ID `1255206635`
